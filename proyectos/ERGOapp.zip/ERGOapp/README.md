# Walkthrough Ergonómico - Proyecto J&J

Este desarrollado por Brandon Cortes conforme a la NOM-036-1-STPS e ISO 11228. Está diseñada para funcionar de forma local en dispositivos Android con Termux.

---

## ✅ Requisitos Previos

Asegúrate de tener instaladas las siguientes herramientas en tu dispositivo Android:

1. **Termux** (última versión desde F-Droid)
2. **Acceso a almacenamiento habilitado en Termux**:
   ```bash
   termux-setup-storage
   ```

---

## 📦 Instalación de Paquetes Necesarios

Abre Termux y ejecuta los siguientes comandos:

```bash
pkg update && pkg upgrade
pkg install nodejs
pkg install git
pkg install nano      # Editor de texto (opcional)
pkg install pm2       # Para mantener el servidor corriendo
```

---

## 🚀 Instalación del Proyecto

1. **Copia o descomprime el contenido del proyecto en la carpeta `~/J_J_new`**  
   Puedes moverlo desde el almacenamiento con:
   ```bash
   mv /sdcard/Download/J_J_new ~/J_J_new
   ```

2. **Navega al directorio del proyecto**:
   ```bash
   cd ~/J_J_new
   ```

3. **Instala las dependencias de Node.js**:
   ```bash
   npm install
   ```

---

## ▶️ Ejecución de la App

Usar script automático con PM2

Si quieres que la app se mantenga activa en segundo plano y se inicie más fácilmente:

```bash
bash iniciar-app.sh
```

Este script hará lo siguiente:
- Mantiene despierto el dispositivo (`termux-wake-lock`)
- Inicia el servidor con PM2 (o lo recupera si ya fue configurado)
- Abre automáticamente el navegador en `http://localhost:3000`

---

## 🔄 Para futuras ejecuciones automáticas

Una vez instalado PM2 y configurado el servidor, solo necesitas correr:

```bash
pm2 resurrect
```

Esto volverá a levantar el servidor sin reinstalar nada.

---

