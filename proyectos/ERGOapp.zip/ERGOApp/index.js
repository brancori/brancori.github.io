// index.js - Sistema de Evaluación Ergonómica
class IndexApp {
    constructor() {
        this.currentUser = null;
        this.init();
    }

    init() {
        this.checkExistingSession();
        this.setupEventListeners();
        this.showLoginModal();
    }

checkExistingSession() {
    const userData = localStorage.getItem('currentUser');
    const sessionExpiry = localStorage.getItem('sessionExpiry');
    
    if (userData && sessionExpiry) {
        const now = new Date().getTime();
        if (now < parseInt(sessionExpiry)) {
            try {
                this.currentUser = JSON.parse(userData);
                this.hideLoginModal();
                this.showMainContent();
                this.updateUserInterface();
                this.loadDashboardData();
                return;
            } catch (error) {
                console.error('Error al cargar sesión:', error);
            }
        }
    }
    
    // Si no hay sesión válida, ocultar contenido
    this.hideMainContent();
    localStorage.removeItem('currentUser');
    localStorage.removeItem('sessionExpiry');
}

    // Configurar event listeners
    setupEventListeners() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        const loginBtn = document.getElementById('loginBtn');
        
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }

        // Ir a áreas button
        const goToAreasBtn = document.getElementById('goToAreasBtn');
        if (goToAreasBtn) {
            goToAreasBtn.addEventListener('click', () => this.navigateToAreas());
        }

        // Logout button
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        // Enter key in login form
        const passwordInput = document.getElementById('password');
        if (passwordInput) {
            passwordInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.handleLogin(e);
                }
            });
        }
    }

    // Manejar el login
    async handleLogin(e) {
        e.preventDefault();
        
        const usuario = document.getElementById('usuario').value.trim();
        const password = document.getElementById('password').value;
        const loginBtn = document.getElementById('loginBtn');
        const loginError = document.getElementById('loginError');
        
        if (!usuario || !password) {
            this.showLoginError('Por favor completa todos los campos');
            return;
        }

        // Mostrar loading
        loginBtn.disabled = true;
        loginBtn.innerHTML = '<span class="icon">⏳</span> Verificando...';
        loginError.style.display = 'none';

        try {
            // Intentar login con Supabase
            const userData = await supabase.loginUser(usuario, password);
            
            if (userData) {
                // Login exitoso
                this.currentUser = userData;
                const expiryTime = new Date().getTime() + (2 * 60 * 60 * 1000); // 2 horas
                localStorage.setItem('currentUser', JSON.stringify(userData));
                localStorage.setItem('sessionExpiry', expiryTime.toString());
                
                this.hideLoginModal();
                this.showMainContent();
                this.updateUserInterface();
                this.showToast('Bienvenido al sistema', 'success');
                
                // Opcional: log de acceso
                console.log('Usuario logueado:', {
                    nombre: userData.nombre,
                    puesto: userData.puesto,
                    rango: userData.rango
                });
            } else {
                this.showLoginError('Usuario o contraseña incorrectos');
            }
        } catch (error) {
            console.error('Error en login:', error);
            this.showLoginError('Error de conexión. Intenta nuevamente.');
        } finally {
            // Restaurar botón
            loginBtn.disabled = false;
            loginBtn.innerHTML = '<span class="icon">🔐</span> Iniciar Sesión';
        }
    }

    // Mostrar error en login
    showLoginError(message) {
        const loginError = document.getElementById('loginError');
        if (loginError) {
            loginError.textContent = message;
            loginError.style.display = 'block';
        }
    }

    // Mostrar modal de login
    showLoginModal() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.classList.add('show');
            // Focus en el campo usuario
            setTimeout(() => {
                const usuarioInput = document.getElementById('usuario');
                if (usuarioInput) usuarioInput.focus();
            }, 100);
        }
    }

    // Ocultar modal de login
    hideLoginModal() {
        const modal = document.getElementById('loginModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    // Actualizar interfaz con datos del usuario
    updateUserInterface() {
        if (!this.currentUser) return;

        const userName = document.getElementById('userName');
        const userRole = document.getElementById('userRole');

        // Mostrar el NOMBRE (no el usuario) en la interfaz
        if (userName) {
            userName.textContent = this.currentUser.nombre || 'Usuario';
        }

        if (userRole) {
            userRole.textContent = this.currentUser.puesto || 'Sin cargo definido';
        }

        // Debug - mostrar estructura del usuario
        console.log('Datos del usuario logueado:', {
            id: this.currentUser.id,
            usuario: this.currentUser.usuario, // Campo para login
            nombre: this.currentUser.nombre,   // Nombre visible
            puesto: this.currentUser.puesto,
            rango: this.currentUser.rango
        });

        // Mostrar permisos en consola para debug
        this.logUserPermissions();
    }

            // AGREGAR estas funciones nuevas:
        showMainContent() {
            const container = document.querySelector('.container');
            if (container) {
                container.style.display = 'block';  // ← Esto debería sobrescribir el CSS
                container.style.opacity = '0';
                container.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    container.style.transition = 'all 0.5s ease';
                    container.style.opacity = '1';
                    container.style.transform = 'translateY(0)';
                }, 100);
            }
        }

        hideMainContent() {
            const container = document.querySelector('.container');
            if (container) {
                container.classList.add('hidden');
            }
        }

        showMainContent() {
            const container = document.querySelector('.container');
            if (container) {
                container.style.setProperty('display', 'block', 'important');
                container.style.opacity = '0';
                container.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    container.style.transition = 'all 0.5s ease';
                    container.style.opacity = '1';
                    container.style.transform = 'translateY(0)';
                }, 100);
            }
        }

    // Log de permisos del usuario
    logUserPermissions() {
        const rangoTexto = {
            1: 'Administrador (CRUD completo)',
            2: 'Editor (Leer y crear)',
            3: 'Visualizador (Solo lectura)'
        };

        console.log('Permisos del usuario:', {
            rango: this.currentUser.rango,
            descripcion: rangoTexto[this.currentUser.rango] || 'Rango desconocido'
        });
    }

    // Navegar a la página de áreas
    navigateToAreas() {
        if (!this.currentUser) {
            this.showToast('Debes iniciar sesión primero', 'error');
            this.showLoginModal();
            return;
        }

        // Guardar timestamp de último acceso
        const accessData = {
            ...this.currentUser,
            lastAccess: new Date().toISOString()
        };
        localStorage.setItem('currentUser', JSON.stringify(accessData));

        // Navegar a áreas
        window.location.href = 'areas.html';
    }

    // Manejar logout
    handleLogout() {
        if (confirm('¿Estás seguro que deseas cerrar sesión?')) {
            localStorage.removeItem('currentUser');
            localStorage.removeItem('sessionExpiry');
            this.hideMainContent();
            this.currentUser = null;
            this.showToast('Sesión cerrada correctamente', 'success');
            
            // Mostrar login modal después de un breve delay
            setTimeout(() => {
                this.showLoginModal();
                // Limpiar campos
                document.getElementById('usuario').value = '';
                document.getElementById('password').value = '';
                document.getElementById('loginError').style.display = 'none';
            }, 1000);
        }
    }

    // Mostrar notificaciones toast
    showToast(message, type = 'info') {
        const toast = document.getElementById('toast');
        if (!toast) return;

        toast.textContent = message;
        toast.className = `toast ${type}`;
        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // Verificar permisos del usuario
    hasPermission(action) {
        if (!this.currentUser) return false;

        const rango = this.currentUser.rango;
        
        switch (action) {
            case 'read':
                return [1, 2, 3].includes(rango); // Todos pueden leer
            case 'create':
                return [1, 2].includes(rango); // Admin y Editor
            case 'update':
                return [1].includes(rango); // Solo Admin
            case 'delete':
                return [1].includes(rango); // Solo Admin
            default:
                return false;
        }
    }

    // Obtener datos del usuario actual
    getCurrentUser() {
        return this.currentUser;
    }

async loadDashboardData() {
    try {
        const dashboardData = await supabase.getDashboardData();
        this.updateDashboardTables(dashboardData);
    } catch (error) {
        console.error('Error cargando datos del dashboard:', error);
    }
}

updateDashboardTables(data) {
    // Actualizar tabla de áreas
    const { areas, topRisk } = data;
    
    // Llenar tabla de porcentaje por área
    areas.forEach((area, index) => {
        if (index < 5) {
            const nameCell = document.getElementById(`area${index + 1}-name`);
            const scoreCell = document.getElementById(`area${index + 1}-score`);
            if (nameCell) nameCell.textContent = area.name;
            if (scoreCell) scoreCell.textContent = `${area.promedio}%`;
        }
    });
    
    // Calcular promedio general
    if (areas.length > 0) {
        const promedioGeneral = (areas.reduce((sum, area) => sum + parseFloat(area.promedio), 0) / areas.length).toFixed(2);
        const promGeneralCell = document.getElementById('promedio-general');
        if (promGeneralCell) promGeneralCell.textContent = `${promedioGeneral}%`;
    }
    
    // Llenar tabla de top riesgo
    topRisk.forEach((item, index) => {
        if (index < 7) {
            const areaCell = document.getElementById(`top${index + 1}-area`);
            const centerCell = document.getElementById(`top${index + 1}-center`);
            const scoreCell = document.getElementById(`top${index + 1}-score`);
            
            if (areaCell) areaCell.textContent = item.area_name;
            if (centerCell) centerCell.textContent = item.center_name;
            if (scoreCell) {
                scoreCell.textContent = `${item.score}%`;
                // Actualizar clase de riesgo
                const row = scoreCell.closest('.table-row');
                if (row) {
                    row.className = 'table-row';
                    if (parseFloat(item.score) >= 60) {
                        row.classList.add('high-risk');
                        scoreCell.className = 'cell score-high';
                    } else if (parseFloat(item.score) >= 50) {
                        row.classList.add('medium-risk');
                        scoreCell.className = 'cell score-medium';
                    }
                }
            }
        }
    });
}

    // Método para verificar el estado de la conexión
    async checkConnection() {
        try {
            await supabase.query('usuarios', 'GET', null, '?limit=1');
            return true;
        } catch (error) {
            console.error('Error de conexión:', error);
            return false;
        }
    }
}

// Funciones auxiliares globales
window.indexApp = null;

// Inicializar aplicación cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 Iniciando Sistema de Evaluación Ergonómica');
    
    // Verificar que Supabase esté disponible
    if (typeof supabase === 'undefined') {
        console.error('❌ Supabase no está disponible. Verifica que supabase-config.js esté cargado.');
        alert('Error: No se pudo conectar con la base de datos. Recarga la página.');
        return;
    }

    // Inicializar aplicación
    window.indexApp = new IndexApp();
    
    console.log('✅ Sistema inicializado correctamente');
});

// Manejar errores globales
window.addEventListener('error', (e) => {
    console.error('Error global:', e.error);
});

// Manejar promesas rechazadas
window.addEventListener('unhandledrejection', (e) => {
    console.error('Promesa rechazada:', e.reason);
});

